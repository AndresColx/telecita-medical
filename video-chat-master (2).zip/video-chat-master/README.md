# Video Chat

[Slides](http://slides.com/basscord/webrtc-video-streaming/) | [Demo](https://video-chat.basscord.co/your-clever-room-name)

Simple app that allows peer to peer video chats.

Create a room by going to [https://video-chat.basscord.co/](https://video-chat.basscord.co/)[room-name-goes-here]

Send that url to a friend and video chatting will commence.
